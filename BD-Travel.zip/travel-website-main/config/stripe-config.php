<?php
define('STRIPE_PUBLISHABLE_KEY', 'pk_test_51QLLqbJcVq5mfW9UuULwTh36xX4C0tEYKKVp7W4AF7RbPCR46NHHcVR9N5LrGmh5zcWnQukTdFXMQl0v867TdrqQ00ZDiRsvQ3');
define('STRIPE_SECRET_KEY', 'sk_test_51QLLqbJcVq5mfW9UcfkUMQE5rZ1Co5Q3wPMA2NoD1XtkdHze6oJvVq9l7VDs0lKLcxupPq54Q2fpM9U9XC09zxrU00FDoeS8g6');
define('STRIPE_WEBHOOK_SECRET', 'your_webhook_secret_here');

// Database configuration
define('DB_HOST', 'localhost');
define('DB_USERNAME', 'your_username');
define('DB_PASSWORD', 'your_password');
define('DB_NAME', 'your_database');
?> 