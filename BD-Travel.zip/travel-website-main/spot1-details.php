<?php 
session_start();
$pageTitle = "Cox's Bazar Beach - BD Adventures";
include 'components/header.php';
include 'components/nav.php';
require_once 'config/db.php';

// Stripe configuration
require_once __DIR__ . '/vendor/autoload.php';
require_once __DIR__ . '/config/stripe-config.php';
\Stripe\Stripe::setApiKey(STRIPE_SECRET_KEY);

$destination_id = 1; // Cox's Bazar destination ID
try {
    $stmt = $pdo->prepare("
        SELECT r.*, u.first_name, u.last_name, r.created_at
        FROM reviews r
        JOIN users u ON r.user_id = u.id
        WHERE r.destination_id = ?
        ORDER BY r.created_at DESC
    ");
    $stmt->execute([$destination_id]);
    $reviews = $stmt->fetchAll();
} catch (PDOException $e) {
    error_log($e->getMessage());
    $reviews = [];
}
?>

<div class="destination-details" style="margin-top: 80px;">
    <div class="container">
        <!-- About Section -->
        <div class="card">
            <h2>About Cox's Bazar</h2>
            <p>Cox's Bazar is the longest natural sea beach in the world, stretching over 120 kilometers along the Bay of Bengal. This unbroken stretch of golden sandy beach is a paradise for beach lovers and adventure seekers alike.</p>
        </div>

        <!-- Highlights Section -->
        <div class="card">
            <h2>Highlights</h2>
            <div class="highlights-list">
                <div class="highlight-item">
                    <i class="fas fa-umbrella-beach"></i>
                    <span>120km of unbroken sandy beach</span>
                </div>
                <div class="highlight-item">
                    <i class="fas fa-sun"></i>
                    <span>View both sunrise and sunset</span>
                </div>
                <div class="highlight-item">
                    <i class="fas fa-water"></i>
                    <span>Various water sports activities</span>
                </div>
                <div class="highlight-item">
                    <i class="fas fa-fish"></i>
                    <span>Fresh seafood restaurants</span>
                </div>
                <div class="highlight-item">
                    <i class="fas fa-store"></i>
                    <span>Local handicraft markets</span>
                </div>
            </div>
        </div>

        <!-- Things to Do Section -->
        <h2>Things to Do</h2>
        <div class="activities-grid">
            <div class="card activity-card">
                <i class="fas fa-camera"></i>
                <h3>Photography</h3>
                <p>Capture stunning sunrise and sunset views</p>
            </div>
            <div class="card activity-card">
                <i class="fas fa-ship"></i>
                <h3>Boat Rides</h3>
                <p>Traditional boat tours along the coast</p>
            </div>
            <div class="card activity-card">
                <i class="fas fa-shopping-bag"></i>
                <h3>Shopping</h3>
                <p>Local markets and souvenir shops</p>
            </div>
        </div>

        <!-- Location Section -->
        <div class="card">
            <h2>Location & How to Reach</h2>
            <p class="location-desc">
                <i class="fas fa-map-marker-alt"></i>
                Located in Cox's Bazar district, about 150 kilometers south of Chittagong
            </p>
            
            <div class="transport-options">
                <div class="transport-card">
                    <i class="fas fa-bus"></i>
                    <h4>By Bus:</h4>
                    <p>Regular bus services from major cities</p>
                </div>
                
                <div class="transport-card">
                    <i class="fas fa-plane"></i>
                    <h4>By Air:</h4>
                    <p>Direct flights from Dhaka to Cox's Bazar Airport</p>
                </div>
                
                <div class="transport-card">
                    <i class="fas fa-train"></i>
                    <h4>By Train:</h4>
                    <p>Train service available up to Chittagong</p>
                </div>
            </div>
        </div>

        <!-- Plan Your Visit Section -->
        <div class="card">
            <h2>Plan Your Visit</h2>
            <div class="plan-details">
                <div class="plan-item">
                    <i class="fas fa-calendar-alt"></i>
                    <div>
                        <h4>Best Time to Visit</h4>
                        <p>November to March (Dry Season)</p>
                    </div>
                </div>
                
                <div class="plan-item">
                    <i class="fas fa-clock"></i>
                    <div>
                        <h4>Recommended Duration</h4>
                        <p>3-4 days</p>
                    </div>
                </div>
                
                <div class="plan-item">
                    <i class="fas fa-ticket-alt"></i>
                    <div>
                        <h4>Ready to Go?</h4>
                        <a href="booking.php?destination=coxs-bazar" class="book-now-btn">Book Now</a>
                    </div>
                    <div>
                        payment with bkash
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.destination-details {
    background-color: #fff5f2;
    padding: 40px 0;
    min-height: 80vh;
}

.container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 20px;
}

.card {
    background: white;
    border-radius: 15px;
    padding: 25px;
    margin-bottom: 30px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.05);
}

h2 {
    color: #333;
    margin-bottom: 20px;
    font-size: 1.8em;
}

.highlights-list {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 20px;
}

.highlight-item {
    display: flex;
    align-items: center;
    gap: 15px;
}

.highlight-item i {
    font-size: 1.5em;
    color: #ff6b35;
}

.activities-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 30px;
    margin-bottom: 30px;
}

.activity-card {
    text-align: center;
    padding: 30px;
}

.activity-card i {
    font-size: 2.5em;
    color: #ff6b35;
    margin-bottom: 15px;
}

.transport-options {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 20px;
    margin-top: 20px;
}

.transport-card {
    background: #fff5f2;
    padding: 20px;
    border-radius: 10px;
    text-align: center;
}

.transport-card i {
    font-size: 2em;
    color: #ff6b35;
    margin-bottom: 10px;
}

.plan-details {
    display: grid;
    gap: 20px;
}

.plan-item {
    display: flex;
    align-items: center;
    gap: 20px;
}

.plan-item i {
    font-size: 1.8em;
    color: #ff6b35;
}

.book-now-btn {
    display: inline-block;
    background: #ff6b35;
    color: white;
    padding: 10px 25px;
    border-radius: 25px;
    text-decoration: none;
    margin-top: 10px;
    transition: background 0.3s;
}

.book-now-btn:hover {
    background: #ff5a1f;
}

@media (max-width: 768px) {
    .activities-grid {
        grid-template-columns: 1fr;
    }
    
    .transport-options {
        grid-template-columns: 1fr;
    }
}
</style>

<?php include 'components/footer.php'; ?> 