const firebaseConfig = {
    apiKey: "your-api-key",
    authDomain: "bd-adventures-by-ovisoft.firebaseapp.com",
    projectId: "bd-adventures-by-ovisoft",
    storageBucket: "bd-adventures-by-ovisoft.appspot.com",
    messagingSenderId: "your-sender-id",
    appId: "your-app-id"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig); 