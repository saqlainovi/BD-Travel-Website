<?php
require_once 'vendor/autoload.php';
require_once 'config/db.php';

// Set your secret key
\Stripe\Stripe::setApiKey('sk_test_51QQDnCAJvlwLoCAn6sfX5ARFGQSKrQH3Nx1xscwsg71U3bLMxx5nhARokqxv5qptjDQS2upk6q7s86H26SvcyHuk00CouhBL58');

try {
    // Get JSON input
    $json_str = file_get_contents('php://input');
    $json_obj = json_decode($json_str);

    // Create a PaymentIntent
    $payment_intent = \Stripe\PaymentIntent::create([
        'amount' => $json_obj->amount,
        'currency' => $json_obj->currency,
        'payment_method' => $json_obj->payment_method_id,
        'confirmation_method' => 'manual',
        'confirm' => true,
        'metadata' => [
            'user_id' => $json_obj->user_id,
            'package_id' => $json_obj->package_id,
            'travel_date' => $json_obj->travel_date,
            'number_of_persons' => $json_obj->number_of_persons
        ]
    ]);

    if ($payment_intent->status === 'succeeded') {
        // Update the bookings table
        $stmt = $pdo->prepare("
            INSERT INTO bookings (
                user_id, 
                package_id, 
                booking_date, 
                travel_date, 
                number_of_persons, 
                total_amount, 
                status, 
                payment_status
            ) VALUES (
                :user_id,
                :package_id,
                CURDATE(),
                :travel_date,
                :number_of_persons,
                :total_amount,
                'confirmed',
                'completed'
            )
        ");

        $stmt->execute([
            ':user_id' => $json_obj->user_id,
            ':package_id' => $json_obj->package_id,
            ':travel_date' => $json_obj->travel_date,
            ':number_of_persons' => $json_obj->number_of_persons,
            ':total_amount' => $json_obj->amount / 100 // Convert from cents to actual amount
        ]);

        $response = [
            'success' => true,
            'payment_intent' => $payment_intent,
            'booking_id' => $pdo->lastInsertId()
        ];
    } else {
        $response = [
            'error' => 'Payment failed'
        ];
    }
} catch (\Stripe\Exception\CardException $e) {
    // Card was declined
    $response = [
        'error' => $e->getMessage()
    ];
} catch (Exception $e) {
    $response = [
        'error' => 'An error occurred while processing your payment'
    ];
}

header('Content-Type: application/json');
echo json_encode($response);
?> 