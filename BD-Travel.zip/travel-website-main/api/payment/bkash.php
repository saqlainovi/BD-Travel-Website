<?php
require_once 'config.php';

class BkashPayment {
    private $pdo;
    
    public function __construct($pdo) {
        $this->pdo = $pdo;
    }
    
    // Create a new bKash transaction
    public function createTransaction($amount) {
        try {
            $stmt = $this->pdo->prepare("
                INSERT INTO bkash_transactions (transaction_id, amount, status, created_at)
                VALUES (:transaction_id, :amount, 'pending', NOW())
            ");
            
            $transaction_id = uniqid('BK_');
            $stmt->execute([
                ':transaction_id' => $transaction_id,
                ':amount' => $amount
            ]);
            
            return [
                'success' => true,
                'transaction_id' => $transaction_id,
                'amount' => $amount
            ];
        } catch (PDOException $e) {
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }
    
    // Verify a bKash transaction
    public function verifyTransaction($transaction_id) {
        try {
            $stmt = $this->pdo->prepare("
                SELECT * FROM bkash_transactions 
                WHERE transaction_id = :transaction_id
            ");
            $stmt->execute([':transaction_id' => $transaction_id]);
            $transaction = $stmt->fetch();
            
            if (!$transaction) {
                return [
                    'success' => false,
                    'error' => 'Transaction not found'
                ];
            }
            
            // Update transaction status
            $updateStmt = $this->pdo->prepare("
                UPDATE bkash_transactions 
                SET status = 'verified', verified_at = NOW()
                WHERE transaction_id = :transaction_id
            ");
            $updateStmt->execute([':transaction_id' => $transaction_id]);
            
            return [
                'success' => true,
                'transaction' => $transaction
            ];
        } catch (PDOException $e) {
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }
    
    // Get transaction status
    public function getTransactionStatus($transaction_id) {
        try {
            $stmt = $this->pdo->prepare("
                SELECT status, amount, created_at, verified_at
                FROM bkash_transactions 
                WHERE transaction_id = :transaction_id
            ");
            $stmt->execute([':transaction_id' => $transaction_id]);
            return $stmt->fetch();
        } catch (PDOException $e) {
            return false;
        }
    }
}

// Handle POST requests for bKash payments
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $bkash = new BkashPayment($pdo);
    $data = json_decode(file_get_contents('php://input'), true);
    
    switch ($data['action']) {
        case 'create':
            if (isset($data['amount'])) {
                $result = $bkash->createTransaction($data['amount']);
                echo json_encode($result);
            }
            break;
            
        case 'verify':
            if (isset($data['transaction_id'])) {
                $result = $bkash->verifyTransaction($data['transaction_id']);
                echo json_encode($result);
            }
            break;
            
        case 'status':
            if (isset($data['transaction_id'])) {
                $result = $bkash->getTransactionStatus($data['transaction_id']);
                echo json_encode($result);
            }
            break;
            
        default:
            echo json_encode([
                'success' => false,
                'error' => 'Invalid action'
            ]);
    }
} 