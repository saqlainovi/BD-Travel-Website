<?php
require_once 'config.php';
require_once 'bkash.php';
require_once 'coupon.php';

class BookingManager {
    private $pdo;
    private $couponManager;
    private $bkashPayment;
    
    public function __construct($pdo) {
        $this->pdo = $pdo;
        $this->couponManager = new CouponManager($pdo);
        $this->bkashPayment = new BkashPayment($pdo);
    }
    
    // Create a new booking
    public function createBooking($data) {
        try {
            // Validate travel date
            if (!validateDate($data['travel_date'])) {
                return [
                    'success' => false,
                    'error' => 'Invalid travel date format'
                ];
            }
            
            // Start transaction
            $this->pdo->beginTransaction();
            
            // Calculate total amount
            $total_amount = $this->calculateTotalAmount($data['package_id'], $data['number_of_persons']);
            
            // Apply coupon if provided
            $discount_amount = 0;
            $coupon_id = null;
            if (isset($data['coupon_code'])) {
                $coupon_result = $this->couponManager->applyCoupon($data['coupon_code'], $total_amount);
                if ($coupon_result['success']) {
                    $discount_amount = $coupon_result['discount'];
                    $coupon_id = $coupon_result['coupon']['id'];
                    $total_amount = $coupon_result['final_amount'];
                }
            }
            
            // Create booking record
            $stmt = $this->pdo->prepare("
                INSERT INTO bookings (
                    user_id, package_id, booking_date, travel_date,
                    number_of_persons, total_amount, status,
                    payment_status, coupon_id, discount_amount
                ) VALUES (
                    :user_id, :package_id, CURDATE(), :travel_date,
                    :number_of_persons, :total_amount, 'pending',
                    'pending', :coupon_id, :discount_amount
                )
            ");
            
            $stmt->execute([
                ':user_id' => $data['user_id'],
                ':package_id' => $data['package_id'],
                ':travel_date' => $data['travel_date'],
                ':number_of_persons' => $data['number_of_persons'],
                ':total_amount' => $total_amount,
                ':coupon_id' => $coupon_id,
                ':discount_amount' => $discount_amount
            ]);
            
            $booking_id = $this->pdo->lastInsertId();
            
            // Process payment based on payment method
            $payment_result = null;
            switch ($data['payment_method']) {
                case 'bkash':
                    $payment_result = $this->bkashPayment->createTransaction($total_amount);
                    break;
                    
                case 'stripe':
                    // Implement Stripe payment processing here
                    break;
                    
                default:
                    throw new Exception('Invalid payment method');
            }
            
            if (!$payment_result['success']) {
                throw new Exception('Payment initialization failed');
            }
            
            $this->pdo->commit();
            
            return [
                'success' => true,
                'booking_id' => $booking_id,
                'payment' => $payment_result,
                'total_amount' => $total_amount,
                'discount_amount' => $discount_amount
            ];
            
        } catch (Exception $e) {
            $this->pdo->rollBack();
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }
    
    // Calculate total amount
    private function calculateTotalAmount($package_id, $number_of_persons) {
        $stmt = $this->pdo->prepare("
            SELECT price FROM packages WHERE id = :id
        ");
        $stmt->execute([':id' => $package_id]);
        $package = $stmt->fetch();
        
        if (!$package) {
            throw new Exception('Package not found');
        }
        
        return $package['price'] * $number_of_persons;
    }
    
    // Get booking details
    public function getBooking($booking_id) {
        try {
            $stmt = $this->pdo->prepare("
                SELECT b.*, p.title as package_title, p.duration, p.tour_type,
                       c.code as coupon_code, c.discount_type, c.discount_value
                FROM bookings b
                LEFT JOIN packages p ON b.package_id = p.id
                LEFT JOIN coupons c ON b.coupon_id = c.id
                WHERE b.id = :id
            ");
            $stmt->execute([':id' => $booking_id]);
            return $stmt->fetch();
        } catch (PDOException $e) {
            return false;
        }
    }
    
    // Update booking status
    public function updateBookingStatus($booking_id, $status, $payment_status = null) {
        try {
            $sql = "UPDATE bookings SET status = :status";
            $params = [':id' => $booking_id, ':status' => $status];
            
            if ($payment_status) {
                $sql .= ", payment_status = :payment_status";
                $params[':payment_status'] = $payment_status;
            }
            
            $sql .= " WHERE id = :id";
            
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute($params);
            
            return true;
        } catch (PDOException $e) {
            return false;
        }
    }
}

// Handle POST requests for bookings
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $bookingManager = new BookingManager($pdo);
    $data = json_decode(file_get_contents('php://input'), true);
    
    switch ($data['action']) {
        case 'create':
            if (isset($data['booking_data'])) {
                $result = $bookingManager->createBooking($data['booking_data']);
                echo json_encode($result);
            }
            break;
            
        case 'get':
            if (isset($data['booking_id'])) {
                $result = $bookingManager->getBooking($data['booking_id']);
                echo json_encode([
                    'success' => true,
                    'booking' => $result
                ]);
            }
            break;
            
        case 'update_status':
            if (isset($data['booking_id']) && isset($data['status'])) {
                $result = $bookingManager->updateBookingStatus(
                    $data['booking_id'],
                    $data['status'],
                    $data['payment_status'] ?? null
                );
                echo json_encode([
                    'success' => $result
                ]);
            }
            break;
            
        default:
            echo json_encode([
                'success' => false,
                'error' => 'Invalid action'
            ]);
    }
} 