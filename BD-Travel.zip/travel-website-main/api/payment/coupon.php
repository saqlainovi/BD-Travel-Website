<?php
require_once 'config.php';

class CouponManager {
    private $pdo;
    
    public function __construct($pdo) {
        $this->pdo = $pdo;
    }
    
    // Validate and apply coupon
    public function applyCoupon($code, $total_amount) {
        try {
            $stmt = $this->pdo->prepare("
                SELECT * FROM coupons 
                WHERE code = :code 
                AND status = 'active'
                AND start_date <= CURDATE()
                AND end_date >= CURDATE()
                AND (usage_limit IS NULL OR times_used < usage_limit)
            ");
            $stmt->execute([':code' => $code]);
            $coupon = $stmt->fetch();
            
            if (!$coupon) {
                return [
                    'success' => false,
                    'error' => 'Invalid or expired coupon'
                ];
            }
            
            // Check minimum purchase requirement
            if ($coupon['min_purchase'] && $total_amount < $coupon['min_purchase']) {
                return [
                    'success' => false,
                    'error' => 'Minimum purchase amount not met'
                ];
            }
            
            // Calculate discount
            $discount = calculateDiscount($total_amount, $coupon);
            
            // Update usage count
            $updateStmt = $this->pdo->prepare("
                UPDATE coupons 
                SET times_used = times_used + 1
                WHERE id = :id
            ");
            $updateStmt->execute([':id' => $coupon['id']]);
            
            return [
                'success' => true,
                'coupon' => $coupon,
                'discount' => $discount,
                'final_amount' => $total_amount - $discount
            ];
        } catch (PDOException $e) {
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }
    
    // Create a new coupon
    public function createCoupon($data) {
        try {
            $stmt = $this->pdo->prepare("
                INSERT INTO coupons (
                    code, discount_type, discount_value, 
                    min_purchase, max_discount, start_date, 
                    end_date, usage_limit, status
                ) VALUES (
                    :code, :discount_type, :discount_value,
                    :min_purchase, :max_discount, :start_date,
                    :end_date, :usage_limit, :status
                )
            ");
            
            $stmt->execute([
                ':code' => $data['code'],
                ':discount_type' => $data['discount_type'],
                ':discount_value' => $data['discount_value'],
                ':min_purchase' => $data['min_purchase'] ?? null,
                ':max_discount' => $data['max_discount'] ?? null,
                ':start_date' => $data['start_date'],
                ':end_date' => $data['end_date'],
                ':usage_limit' => $data['usage_limit'] ?? null,
                ':status' => 'active'
            ]);
            
            return [
                'success' => true,
                'message' => 'Coupon created successfully'
            ];
        } catch (PDOException $e) {
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }
    
    // Get all active coupons
    public function getActiveCoupons() {
        try {
            $stmt = $this->pdo->query("
                SELECT * FROM coupons 
                WHERE status = 'active'
                AND end_date >= CURDATE()
                ORDER BY created_at DESC
            ");
            return $stmt->fetchAll();
        } catch (PDOException $e) {
            return false;
        }
    }
}

// Handle POST requests for coupons
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $couponManager = new CouponManager($pdo);
    $data = json_decode(file_get_contents('php://input'), true);
    
    switch ($data['action']) {
        case 'apply':
            if (isset($data['code']) && isset($data['total_amount'])) {
                $result = $couponManager->applyCoupon($data['code'], $data['total_amount']);
                echo json_encode($result);
            }
            break;
            
        case 'create':
            if (isset($data['coupon_data'])) {
                $result = $couponManager->createCoupon($data['coupon_data']);
                echo json_encode($result);
            }
            break;
            
        case 'list':
            $result = $couponManager->getActiveCoupons();
            echo json_encode([
                'success' => true,
                'coupons' => $result
            ]);
            break;
            
        default:
            echo json_encode([
                'success' => false,
                'error' => 'Invalid action'
            ]);
    }
} 