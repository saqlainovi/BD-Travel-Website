<?php
// Payment Gateway Configurations
define('STRIPE_PUBLISHABLE_KEY', 'pk_test_51QQDnCAJvlwLoCAnyDY6SvAYdLb6c0wolOWUKJZJWXQX1m5xNytxsAEaf0mXzh3Q1saoYSWpqpqGJi9LfZHg8eFS00BEJnVeaQ');
define('STRIPE_SECRET_KEY', 'sk_test_51QQDnCAJvlwLoCAn6sfX5ARFGQSKrQH3Nx1xscwsg71U3bLMxx5nhARokqxv5qptjDQS2upk6q7s86H26SvcyHuk00CouhBL58');

// bKash Configuration
define('BKASH_APP_KEY', 'your_bkash_app_key');
define('BKASH_APP_SECRET', 'your_bkash_app_secret');
define('BKASH_USERNAME', 'your_bkash_username');
define('BKASH_PASSWORD', 'your_bkash_password');
define('BKASH_SANDBOX_MODE', true); // Set to false for production

// General Payment Settings
define('CURRENCY', 'BDT');
define('CURRENCY_SYMBOL', '৳');
define('TAX_RATE', 0.15); // 15% tax rate

// Error Handling
error_reporting(E_ALL);
ini_set('display_errors', 1);
date_default_timezone_set('Asia/Dhaka');

// Database Connection
$db_config = array(
    'host' => 'localhost',
    'username' => 'root',
    'password' => '',
    'database' => 'db'
);

// Initialize Database Connection
try {
    $pdo = new PDO(
        "mysql:host={$db_config['host']};dbname={$db_config['database']};charset=utf8mb4",
        $db_config['username'],
        $db_config['password'],
        array(
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false
        )
    );
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

// Helper Functions
function validateDate($date, $format = 'Y-m-d') {
    $d = DateTime::createFromFormat($format, $date);
    return $d && $d->format($format) === $date;
}

function calculateDiscount($total, $coupon) {
    if ($coupon['discount_type'] === 'percentage') {
        $discount = $total * ($coupon['discount_value'] / 100);
        return min($discount, $coupon['max_discount'] ?? $discount);
    }
    return $coupon['discount_value'];
} 